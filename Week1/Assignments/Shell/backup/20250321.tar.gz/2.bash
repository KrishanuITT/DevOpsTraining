n1=$1
n2=$2

echo "Sum: $((n1 + n2))"
echo "Difference: $((n1 - n2))"
echo "Product: $((n1 * n2))"
echo "Quotient: $((n1 / n2))"
